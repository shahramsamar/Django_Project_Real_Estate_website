

def seo_meta_tags(request):
    return {
        'meta_description': 'Default description for the website.',
    }
